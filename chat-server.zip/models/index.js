module.exports = {
  ChatLog: require('./ChatLog'),
  CustomerStatus: require('./CustomerStatus'),
  ForbiddenWord: require('./ForbiddenWord')
};


